package me.jonny.jclient.module.modules;

import me.jonny.jclient.Client;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

public class PlayerUtils {
  public static Minecraft mc = Minecraft.getMinecraft();

  
  public static void sendMessage(Object message, boolean prefix) {
	    String msg = message.toString();
	    if (prefix)
	      msg = String.valueOf("�e") + msg; 
	    mc.thePlayer.addChatComponentMessage((IChatComponent)new ChatComponentText(msg));
	  }
  
  public static boolean playeriswalking() {
    if (mc.gameSettings.keyBindForward.pressed)
      return true; 
    if (mc.gameSettings.keyBindBack.pressed)
      return true; 
    if (mc.gameSettings.keyBindLeft.pressed)
      return true; 
    if (mc.gameSettings.keyBindRight.pressed)
      return true; 
    return false;
  }
  
  public static boolean playeriswalkingforward() {
    if (mc.gameSettings.keyBindBack.pressed)
      return false; 
    if (mc.gameSettings.keyBindLeft.pressed)
      return false; 
    if (mc.gameSettings.keyBindRight.pressed)
      return false; 
    if (mc.gameSettings.keyBindForward.pressed)
      return true; 
    return false;
  }
  
  public static void sendPosition(double x, double y, double z, boolean onGround) {
    mc.thePlayer.sendQueue.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, onGround));
  }
  
  public static void sendGround(boolean onGround) {
    mc.thePlayer.sendQueue.addToSendQueue((Packet)new C03PacketPlayer(onGround));
  }
}
