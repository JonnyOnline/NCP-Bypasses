package me.jonny.jclient.event.events;

import me.jonny.jclient.event.Event;

public class UpdateEvent extends Event {

}