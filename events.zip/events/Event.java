package me.jonny.jclient.event;

public class Event {

	public Event() {
	}

}